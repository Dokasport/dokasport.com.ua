<?php
// Text
$_['text_footer']  = '<HR><a href="https://www.opencart.ru">OpenCart</a><br> <BR> &nbsp;&nbsp;&nbsp;<a href="https://www.opencart.ru/documentation" target="_blank">Документация</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="https://www.opencart.ru/modules" target="_blank">Маркетплейс</a>';
$_['text_version'] = 'Version %s';

